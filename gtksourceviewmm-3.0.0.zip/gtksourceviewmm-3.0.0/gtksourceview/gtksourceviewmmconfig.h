/* gtksourceview/gtksourceviewmmconfig.h.  Generated from gtksourceviewmmconfig.h.in by configure.  */
#ifndef _GTKSOURCEVIEWMM_CONFIG_H
#define _GTKSOURCEVIEWMM_CONFIG_H

#include <gtkmmconfig.h>

/* Define to omit deprecated API from gtksourceviewmm. */
/* #undef GTKSOURCEVIEWMM_DISABLE_DEPRECATED */

/* Major version number of gtksourceviewmm. */
#define GTKSOURCEVIEWMM_MAJOR_VERSION 3

/* Minor versino number of gtksourceviewmm. */
#define GTKSOURCEVIEWMM_MINOR_VERSION 0

/* Micro version number of gtksourceviewmm. */
#define GTKSOURCEVIEWMM_MICRO_VERSION 0

#endif /* _GTKSOURCEVIEWMM_CONFIG_H */

